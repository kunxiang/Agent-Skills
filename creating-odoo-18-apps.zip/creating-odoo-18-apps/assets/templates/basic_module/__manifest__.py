# -*- coding: utf-8 -*-
{
    'name': 'Module Name',
    'version': '18.0.1.0.0',
    'category': 'Services',
    'summary': 'Short module description',
    'description': """
Module Name
===========

Long description of what this module does.

Features:
- Feature 1
- Feature 2
    """,
    'author': 'Your Company',
    'website': 'https://www.yourcompany.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
