---
name: your-skill-name
description: "Brief description of what this skill does. Use when: (1) trigger condition one, (2) trigger condition two, (3) trigger condition three."
---

# Your Skill Title

## Quick Reference

| Task | Approach |
|------|----------|
| Common task 1 | How to do it |
| Common task 2 | How to do it |
| Common task 3 | How to do it |

## Core Instructions

### Step 1: First Step
[Clear, imperative instructions]

### Step 2: Second Step
[Clear, imperative instructions]

### Step 3: Third Step
[Clear, imperative instructions]

## Examples

### Example 1: Basic Usage
```
[Concrete example with input and expected output]
```

### Example 2: Advanced Usage
```
[More complex example]
```

## Guidelines

- Guideline one (be specific)
- Guideline two (be specific)
- Guideline three (be specific)
